from .models import Comment
from django import forms


class CommentForm(forms.ModelForm):

    def __init__(self,*args,**kwargs):
        super(CommentForm,self).__init__(*args,**kwargs)
        for field in self.fields:
            self.fields[field].widget.attrs={'class':'form-control textarea '}

        self.fields['body'].widget.attrs['placeholder'] = 'Write here'
        self.fields['body'].widget.attrs['rows'] = 6
        self.fields['body'].widget.attrs['class'] = 'body'
        self.fields['body'].widget.attrs['cols'] = 70
        self.fields['name'].widget.attrs['placeholder'] = 'Enter your name'
        self.fields['name'].widget.attrs['class'] = 'name'


    class Meta:
        model = Comment
        fields = ['name','body']
